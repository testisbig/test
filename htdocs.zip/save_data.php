<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Store data in a text file
    $file = fopen("data.txt", "a");
    fwrite($file, "Name: " . $name . ", Email: " . $email . "\n");
    fclose($file);

    // Redirect back to the form
    header("Location: index.html");
    exit();
}
?>
